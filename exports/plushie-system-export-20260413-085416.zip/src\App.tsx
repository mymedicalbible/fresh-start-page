import type { ReactNode } from 'react'
import { Navigate, Route, Routes, useLocation } from 'react-router-dom'
import { useAuth } from './contexts/AuthContext'
import { AppLayout } from './components/AppLayout'
import { LoginPage } from './pages/LoginPage'
import { DashboardPage } from './pages/DashboardPage'
import { QuickLogPage } from './pages/QuickLogPage'
import { AnalyticsPage } from './pages/AnalyticsPage'
import { MedicationsPage } from './pages/MedicationsPage'
import { RecordsPage } from './pages/RecordsPage'
import { DoctorsPage } from './pages/DoctorsPage'
import { DoctorProfilePage } from './pages/DoctorProfilePage'
import { TestsOrderedPage } from './pages/TestsOrderedPage'
import { QuestionsArchivePage } from './pages/QuestionsArchivePage'
import { DiagnosesDirectoryPage } from './pages/DiagnosesDirectoryPage'
import { VisitsPage } from './pages/VisitsPage'
import { ProfilePage } from './pages/ProfilePage'
import { MorePage } from './pages/MorePage'
import { TranscriptsPage } from './pages/TranscriptsPage'
import { SoloRecordingPage } from './pages/SoloRecordingPage'
import { AppointmentsPage } from './pages/AppointmentsPage'
import { PlushieShopPage } from './pages/PlushieShopPage'
import { MyPlushiesPage } from './pages/MyPlushiesPage'
import { NotFoundPage } from './pages/NotFoundPage'


function Protected ({ children }: { children: ReactNode }) {
  const { user, loading } = useAuth()
  if (loading) return <div className="login-wrap muted"><p>Loading…</p></div>
  if (!user) return <Navigate to="/login" replace />
  return <>{children}</>
}

function RedirectFlaresToChartsTrends () {
  const { search } = useLocation()
  return <Navigate to={`/app/charts-trends${search}`} replace />
}


export default function App () {
  return (
    <Routes>
      <Route path="/login" element={<LoginPage />} />
      <Route path="/app" element={<Protected><AppLayout /></Protected>}>
        <Route index element={<DashboardPage />} />
        <Route path="log" element={<QuickLogPage />} />
        <Route path="archives" element={<Navigate to="/app" replace />} />
        <Route path="charts-trends" element={<RecordsPage />} />
        <Route path="records" element={<RecordsPage />} />
        <Route path="flares" element={<RedirectFlaresToChartsTrends />} />
        <Route path="analytics" element={<AnalyticsPage />} />
        <Route path="meds" element={<MedicationsPage />} />
        <Route path="doctors" element={<DoctorsPage />} />
        <Route path="doctors/:id" element={<DoctorProfilePage />} />
        <Route path="tests" element={<TestsOrderedPage />} />
        <Route path="questions" element={<QuestionsArchivePage />} />
        <Route path="diagnoses" element={<DiagnosesDirectoryPage />} />
        <Route path="more" element={<MorePage />} />
        <Route path="transcripts" element={<TranscriptsPage />} />
        <Route path="solo-record" element={<SoloRecordingPage />} />
        <Route path="appointments" element={<AppointmentsPage />} />
        <Route path="visits" element={<VisitsPage />} />
        <Route path="profile" element={<ProfilePage />} />
        <Route path="plushies/mine" element={<MyPlushiesPage />} />
        <Route path="plushies" element={<PlushieShopPage />} />
        <Route path="*" element={<NotFoundPage />} />
      </Route>
      <Route path="/" element={<Navigate to="/login" replace />} />
      <Route path="*" element={<NotFoundPage />} />
    </Routes>
  )
}
